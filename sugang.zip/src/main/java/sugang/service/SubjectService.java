package sugang.service;

public interface SubjectService {

}
